from django.shortcuts import render
from .models import *
# Create your views here.
def home(request):

    cdata=category.objects.all().order_by('-id')[0:12]
    ndata=news.objects.all().order_by('-id')[0:12]
    data=notification.objects.all().order_by('-id')[0:4]
    sdata=slider.objects.all().order_by('-id')
    return render(request,'html_files/home.html',{"data":cdata,"news":ndata,"notification":data,"slider":sdata})

def aboutus(request):
    return render(request,'html_files/aboutus.html')
def viewnews(request):
    return render(request,'html_files/viewnews.html')

def videos(request):
    vdata=video.objects.all().order_by('-id')
    return render(request,'html_files/videos.html',{"video":vdata})

def contactus(request):
    status=False
    if request.method=='POST':
        a=request.POST.get("name","")
        b=request.POST.get("mobile","")
        c=request.POST.get("email","")
        d=request.POST.get("msg","")
        x=contact(name=a,email=c,contact=b,message=d)
        x.save()
        status=True
    return render(request,'html_files/contactus.html',{'S':status})
def login(request):
    return render(request,'html_files/login.html')
def viewmore(request):
    a=request.GET.get('msg')
    ndata=news.objects.filter(id=a)
    return render(request,'html_files/viewmore.html',{"data":ndata})
def vnews(request):
    cdata=category.objects.all().order_by('-id')

    a=request.GET.get('abc')
    ndata=""
    if a is None:
        ndata = news.objects.all().order_by('-id')
    else:
        ndata=news.objects.filter(ncategory=a)

    return render(request,'html_files/news.html',{"c":cdata,"n":ndata})