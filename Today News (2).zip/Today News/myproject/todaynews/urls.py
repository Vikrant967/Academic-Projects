from django.urls import path
from . import views
urlpatterns=[
    path('',views.home),
    path('home/',views.home),
    path('aboutus/',views.aboutus),
    path('viewnews/',views.viewnews),
    path('videos/',views.videos),
    path('contactus/',views.contactus),
    path('login/',views.login),
    path('viewmore/',views.viewmore),
    path('news/',views.vnews),
]