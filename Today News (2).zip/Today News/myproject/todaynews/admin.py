from django.contrib import admin
from.models import *
# Register your models here.
class contactAdmin(admin.ModelAdmin):
    list_display = ("name","contact","email","message")
admin.site.register(contact,contactAdmin)
class categoryAdmin(admin.ModelAdmin):
    list_display = ('id',"cname","cpic")
admin.site.register(category,categoryAdmin)
class newsAdmin(admin.ModelAdmin):
    list_display = ('id',"city","headlines","subject","newsdes","newspic","ndate","ncategory")
admin.site.register(news,newsAdmin)
class notificationAdmin(admin.ModelAdmin):
    list_display = ('id',"ndes","ndate")
admin.site.register(notification,notificationAdmin)
class videoAdmin(admin.ModelAdmin):
    list_display = ('id',"vtitle","vdes","thumb","vlink","vdate")
admin.site.register(video,videoAdmin)
class sliderAdmin(admin.ModelAdmin):
    list_display = ('id',"stitle","sdes","spic","sdate")
admin.site.register(slider,sliderAdmin)
